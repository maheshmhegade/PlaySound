package com.example.convertdate;

import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	EditText etDateDMY, etDateJD;
	TextView twWarning, twJD, twDate;
	Button bConvert, bClear;
	Handler convertHandler = new Handler();
	Handler clearHandler = new Handler();
	private String strDateDMY = new String();
	private String strDateJD = new String();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		startConversionDeamon();
	}

	private void startConversionDeamon() {
		bConvert = (Button) findViewById(R.id.convert);
		bClear = (Button) findViewById(R.id.clear);

		etDateDMY = (EditText) findViewById(R.id.date);
		etDateDMY.setTypeface(null, Typeface.BOLD);
		etDateJD = (EditText) findViewById(R.id.juliandate);
		etDateJD.setTypeface(null, Typeface.BOLD);
		twWarning = (TextView) findViewById(R.id.warning);
		twWarning.setTypeface(null, Typeface.ITALIC);
		twJD = (TextView) findViewById(R.id.stone);
		twJD.setTypeface(null, Typeface.ITALIC);
		twJD.setTypeface(null, Typeface.BOLD);
		twDate = (TextView) findViewById(R.id.sttwo);
		twDate.setTypeface(null, Typeface.ITALIC);
		twDate.setTypeface(null, Typeface.BOLD);

		bConvert.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				// Use a new tread as this can take a while
				final Thread thread = new Thread(new Runnable() {
					public void run() {

						convertHandler.post(new Runnable() {

							public void run() {
								twWarning.setText("");
								strDateDMY = etDateDMY.getText().toString();
								strDateJD = etDateJD.getText().toString();
								if(strDateDMY.compareTo("") == 0)
								{
									if(strDateJD.compareTo("") == 0)
									{
										twWarning.setText("Please give atleast one input");
									}
									else
									{
										String setVal = Julian2Date(strDateJD);
										etDateDMY.setText(setVal);
									}
								}
								else
								{
									String setVal = date2JulianDate(strDateDMY);
									etDateJD.setText(setVal);
								}
							}
						});
					}
				});
				thread.start();
			}

		});

		bClear.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				// Use a new tread as this can take a while
				final Thread thread = new Thread(new Runnable() {
					public void run() {

						clearHandler.post(new Runnable() {

							public void run() {
								twWarning.setText("");
								etDateDMY.setText("");
								etDateJD.setText("");
							}
						});
					}
				});
				thread.start();
			}

		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private String date2JulianDate(String dateInput)
	{
		int d = 0, m = 0 ,y = 0 ;
		String julianValue = new String();
		String date[] = dateInput.split("-");
		try {
			d = Integer.parseInt(date[0]);
			m = Integer.parseInt(date[1]);
			y = Integer.parseInt(date[2]);
		} catch (Exception ex) {
			twWarning.clearComposingText();
			twWarning.setText("Seems like not a valid data");
		}
		int isValid = validateDate(d, m, y);
		if(isValid > 0)
		{
			try {
				Calendar olderDate = new GregorianCalendar();
				Calendar newerDate = new GregorianCalendar();
				olderDate.set(1900, 1-1, 1);
				newerDate.set(y, m-1, d);
				julianValue = String.valueOf(daysBetween(olderDate.getTime(), newerDate.getTime()));
			} catch (Exception ex) {

			}
		}
		return julianValue;
	}

	private int validateDate(int d, int m, int y) {
		int retVal = 1;
		int daysinmonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		try {

			if (y % 400 == 0 || (y % 100 != 0 && y % 4 == 0)) {
				// leap year checking, if ok add 29 days to February
				daysinmonth[1] = 29;
			}

			if (d < 1 || d > daysinmonth[m - 1]) {
				twWarning.clearComposingText();
				twWarning.setText("Invalid date");
				retVal = 0;
			}
			else if (m < 1 || m > 12) {
				twWarning.clearComposingText();
				twWarning.setText("Invalid month");
				retVal = 0;
			} 
			else if (y < 1900) {
				twWarning.clearComposingText();
				twWarning.setText("Endur dont remember dates before 1900 !!");
				retVal = 0;
			}

		} catch (Exception ex) {
			twWarning.clearComposingText();
			twWarning.setText("Unknown error : Recheck the date format again, if it is fine then report to the developer with input");
			retVal = 0;
		}
		return retVal;
	}
	private int daysBetween(Date date, Date date2) {
		return (int) ((date2.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
	}

	String Julian2Date(String julianInput)
	{
		String dateValue = new String();
		int jd = 0;
		try {
			jd = Integer.parseInt(julianInput);
		} catch (Exception ex) {
		}
		try {
			if (jd < 1) {
				twWarning.clearComposingText();
				twWarning.setText("Invalid value cannot be negative");
			}
			GregorianCalendar gcStart = (GregorianCalendar) Calendar
					.getInstance();
			gcStart.set(1900, 0, 1);
			gcStart.add(Calendar.DAY_OF_YEAR, jd);
			dateValue = (String)(gcStart.get(Calendar.DATE) + "-" +
					gcStart.get(Calendar.DAY_OF_MONTH) +"-" + 
					gcStart.get(Calendar.YEAR));
		} catch (Exception ex) {
		}
		return dateValue;
	}

}
