package com.example.playsound;


import java.util.Arrays;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.PointLabelFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;

import SoundBox.SoundBox;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.graphics.Color;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity implements OnItemSelectedListener {

	Spinner spinnerOsversions;
	private String[] waveForm = {"Sine","Triangular","Square","Ramp"};

	Handler handler = new Handler();

	Button button;

	private XYPlot plot;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ArrayAdapter<String> adapter_state = new ArrayAdapter<String>(this,  android.R.layout.simple_spinner_item, waveForm);
		addListenerOnButton();
		spinnerOsversions = (Spinner) findViewById(R.id.Osversions);
		adapter_state.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerOsversions.setAdapter(adapter_state);
	}


	public void addListenerOnButton() {

		button = (Button) findViewById(R.id.button1);

		plotGraph();
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				// Use a new tread as this can take a while
				final Thread thread = new Thread(new Runnable() {
					public void run() {

						handler.post(new Runnable() {

							public void run() {
								for(int j=0; j< 2; j++)
								{
									SoundBox sndBoxObject = new SoundBox();
									String waveType = (String)spinnerOsversions.getSelectedItem();
									sndBoxObject.setWaveType(waveType);
								
									sndBoxObject.playSoundWave(plot);
								}
							}
						});
					}
				});
				thread.start();

			}

		});

	}
	public void plotGraph()
	{
		plot = (XYPlot) findViewById(R.id.mySimpleXYPlot);
		// Create a couple arrays of y-values to plot:
		Number[] series1Numbers = {1, 8, 5, 2, 7, 4};
		Number[] series2Numbers = {4, 6, 3, 8, 2, 10};

		// Turn the above arrays into XYSeries':
		XYSeries series1 = new SimpleXYSeries(
				Arrays.asList(series1Numbers),          // SimpleXYSeries takes a List so turn our array into a List
				SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, // Y_VALS_ONLY means use the element index as the x value
				"Series1");                             // Set the display title of the series

		// same as above
		XYSeries series2 = new SimpleXYSeries(Arrays.asList(series2Numbers), SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, "Series2");

		// Create a formatter to use for drawing a series using LineAndPointRenderer:
		LineAndPointFormatter series1Format = new LineAndPointFormatter(
				Color.rgb(0, 200, 0),                   // line color
				Color.rgb(0, 100, 0),                   // point color
				null,                                   // fill color (none)
				new PointLabelFormatter(Color.WHITE));                           // text color

		// add a new series' to the xyplot:
		plot.addSeries(series1, series1Format);

		// same as above:
		plot.addSeries(series2,
				new LineAndPointFormatter(
						Color.rgb(0, 0, 200),
						Color.rgb(0, 0, 100),
						null,
						new PointLabelFormatter(Color.WHITE)));

		// reduce the number of range labels
		plot.setTicksPerRangeLabel(3);
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		spinnerOsversions.setSelection(position);
	}



	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub

	}

}
